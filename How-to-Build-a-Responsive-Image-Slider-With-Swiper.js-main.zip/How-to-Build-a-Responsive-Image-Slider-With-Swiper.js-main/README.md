# How to Build a Responsive Image Slider With Swiper.js
Source files to accompany Tuts+ short course on swiper.js by Adi Purdila.

**Resources**

- [https://swiperjs.com/](https://swiperjs.com/)
- [https://svgsilh.com/image/1751088.html](https://svgsilh.com/image/1751088.html)
- [https://unsplash.com/s/photos/spain](https://unsplash.com/s/photos/spain)
- [https://en.wikipedia.org/wiki/Spain](https://en.wikipedia.org/wiki/Spain#Geography)
- [https://webdesign.tutsplus.com/tutorials/how-to-build-a-responsive-slider-with-swiperjs--cms-39427](https://webdesign.tutsplus.com/tutorials/how-to-build-a-responsive-slider-with-swiperjs--cms-39427)
